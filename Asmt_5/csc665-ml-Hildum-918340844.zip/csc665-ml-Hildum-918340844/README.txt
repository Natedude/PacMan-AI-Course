# Nathan Hildum = 918 340 844

## Hours spent ~ 6

---

## Q1: Implementation
The run() and get_prediction() methods we're pretty simple. The train() method was a bit more complex, but I just made sure to take things one step at a time. I had a little trouble figuring out exactly how to use the "dataset", but once I figured out how I could put it in the for loop with both x and y in the same line it all came together.

