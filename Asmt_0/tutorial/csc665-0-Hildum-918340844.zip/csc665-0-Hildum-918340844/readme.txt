Name: Nathan Hildum
SFSU ID: 918 340 844

addition.py:
	Copy and pasted def, as instructed, with a basic addition statement and printout.

buyLotsOfFruit.py:
	Iterate through orderList and add up the costs of each weight times the price/weight in the fruitPrices dictionary to get totalCost. If fruit is not in list, return None and print error. Return totalCost.

shopSmart.py:
    Use a minimum finding algorithm to select the shop that returns the lowest cost from its getPriceOfOrder() function and return it.

